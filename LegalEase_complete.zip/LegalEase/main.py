from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from routes import router
from config import get_settings

settings = get_settings()
app = FastAPI(title=settings.app_name, version="1.0.0", description="AI-powered legal document drafting API")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:8501", "http://127.0.0.1:8501"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.include_router(router)

@app.get("/")
def root():
    return {"name": settings.app_name, "message": "LegalEase API is running", "docs": "/docs"}

@app.get("/health")
def health():
    return {"status": "ok", "ai_configured": bool(settings.gemini_api_key), "model": settings.gemini_model}
