from functools import lru_cache
import os
from dotenv import load_dotenv

load_dotenv()

class Settings:
    app_name: str = os.getenv("APP_NAME", "LegalEase")
    gemini_api_key: str = os.getenv("GEMINI_API_KEY", "")
    gemini_model: str = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
    backend_url: str = os.getenv("BACKEND_URL", "http://127.0.0.1:8000")

@lru_cache
def get_settings() -> Settings:
    return Settings()
