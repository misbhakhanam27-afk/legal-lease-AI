import requests
import streamlit as st
from config import get_settings
from utils.exporters import format_docx, format_pdf
from utils.preview import format_html_preview

settings = get_settings()
st.set_page_config(page_title="LegalEase", page_icon="⚖️", layout="wide")

st.markdown("""
<style>
.main-title{text-align:center;font-size:2.4rem;font-weight:700;margin-bottom:.1rem}
.subtitle{text-align:center;color:#777;margin-bottom:1.5rem}
.preview{background:#15171b;color:#f2f2f2;border-radius:14px;padding:24px;max-height:600px;overflow:auto;line-height:1.65}
.preview h3{color:#fff;margin-top:18px}.preview p{margin:7px 0}.preview .spacer{height:8px}
.notice{padding:12px 16px;border-radius:10px;background:#fff3cd;color:#664d03;margin-bottom:12px}
</style>
""", unsafe_allow_html=True)

st.markdown("<div class='main-title'>⚖️ LegalEase</div>", unsafe_allow_html=True)
st.markdown("<div class='subtitle'>AI-powered legal document drafting assistant</div>", unsafe_allow_html=True)
st.info("Drafting aid only: review generated documents with a qualified legal professional before signing or relying on them.")

if "document" not in st.session_state:
    st.session_state.document = ""

with st.form("document_form"):
    c1, c2 = st.columns(2)
    with c1:
        document_type = st.selectbox("Document Type", ["Employment Contract", "Non-Disclosure Agreement", "Lease Agreement", "Employment Offer Letter", "Service Agreement", "Freelance Work Contract", "Custom Agreement"])
        parties = st.text_area("Parties Involved", placeholder="Jane Doe (Service Provider); TechNova Inc. (Client)", height=120)
    with c2:
        effective_date = st.text_input("Effective Date", placeholder="September 24, 2026")
        jurisdiction = st.text_input("Jurisdiction (optional)", placeholder="India")
        terms = st.text_area("Terms & Conditions", placeholder="Payment within 30 days; Confidentiality must be maintained; Either party may terminate with 15 days notice", height=120)
    additional = st.text_area("Additional Instructions (optional)", placeholder="Use professional language. Add placeholders for missing information.", height=90)
    submitted = st.form_submit_button("Generate Document", type="primary", use_container_width=True)

if submitted:
    if not parties.strip() or not terms.strip() or not effective_date.strip():
        st.error("Please fill in parties, terms, and effective date.")
    else:
        payload = {"document_type": document_type, "parties": parties, "terms": terms, "effective_date": effective_date, "jurisdiction": jurisdiction or "Not specified", "additional_instructions": additional}
        try:
            with st.spinner("Generating your draft with Gemini..."):
                response = requests.post(f"{settings.backend_url}/generate", json=payload, timeout=120)
            if response.ok:
                data = response.json()
                st.session_state.document = data["text"]
                st.session_state.document_type = data["document_type"]
                st.session_state.terms = terms
                st.success("Document generated successfully.")
            else:
                detail = response.json().get("detail", response.text)
                st.error(f"Backend error: {detail}")
        except requests.RequestException as exc:
            st.error(f"Could not reach the FastAPI backend at {settings.backend_url}. Start it first. Details: {exc}")

if st.session_state.document:
    st.divider()
    st.subheader("Document Preview")
    edited = st.text_area("Edit Document", value=st.session_state.document, height=450, key="editable_document")
    st.session_state.document = edited
    st.markdown("**Styled preview**")
    st.markdown(f"<div class='preview'>{format_html_preview(edited)}</div>", unsafe_allow_html=True)
    st.write("")
    b1, b2, b3 = st.columns(3)
    with b1:
        st.download_button("Download TXT", data=edited.encode("utf-8"), file_name="legalease_document.txt", mime="text/plain", use_container_width=True)
    with b2:
        st.download_button("Download DOCX", data=format_docx(edited, st.session_state.get("document_type", "Legal Document"), st.session_state.get("terms", "")), file_name="legalease_document.docx", mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document", use_container_width=True)
    with b3:
        st.download_button("Download PDF", data=format_pdf(edited, st.session_state.get("document_type", "Legal Document"), st.session_state.get("terms", "")), file_name="legalease_document.pdf", mime="application/pdf", use_container_width=True)
