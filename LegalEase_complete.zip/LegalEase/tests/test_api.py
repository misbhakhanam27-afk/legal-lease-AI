from fastapi.testclient import TestClient
import routes
from main import app

client = TestClient(app)

def test_health():
    r = client.get('/health')
    assert r.status_code == 200
    assert r.json()['status'] == 'ok'

def test_generate_validation():
    r = client.post('/generate', json={"document_type":"", "parties":"x", "terms":"y", "effective_date":"z"})
    assert r.status_code == 422

def test_generate_with_mock(monkeypatch):
    class FakeGenerator:
        model = 'test-model'
        def __init__(self): pass
        def generate_document(self, **kwargs): return 'TEST AGREEMENT\nGenerated text.'
    monkeypatch.setattr(routes, 'GeminiDocumentGenerator', FakeGenerator)
    r = client.post('/generate', json={"document_type":"Agreement", "parties":"A; B", "terms":"Payment; Confidentiality", "effective_date":"2026-09-24"})
    assert r.status_code == 200
    assert r.json()['text'].startswith('TEST AGREEMENT')
