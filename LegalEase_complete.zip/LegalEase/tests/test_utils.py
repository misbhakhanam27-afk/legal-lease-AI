from utils.sanitizer import sanitize_text, split_terms
from utils.exporters import format_docx, format_pdf

def test_sanitize_text():
    assert sanitize_text('“Hello”—world…') == '"Hello"-world...'

def test_split_terms():
    assert split_terms('A; B;; C') == ['A', 'B', 'C']

def test_docx_export():
    data = format_docx('TEST AGREEMENT\nHello world.', 'Agreement', 'Payment within 30 days; Confidentiality')
    assert data[:2] == b'PK'

def test_pdf_export():
    data = format_pdf('TEST AGREEMENT\nHello world.', 'Agreement', 'Payment within 30 days; Confidentiality')
    assert data.startswith(b'%PDF')
