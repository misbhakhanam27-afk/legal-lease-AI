from config import get_settings
from utils.sanitizer import sanitize_text

class GeminiDocumentGenerator:
    """Gemini-backed legal drafting service."""

    def __init__(self):
        settings = get_settings()
        if not settings.gemini_api_key:
            raise RuntimeError("GEMINI_API_KEY is not configured. Add it to .env.")
        self.model = settings.gemini_model
        from google import genai
        self._genai = genai
        self.client = genai.Client(api_key=settings.gemini_api_key)

    def build_prompt(self, document_type, parties, terms, effective_date, jurisdiction, additional_instructions):
        return f"""
You are LegalEase, a careful legal-document drafting assistant.

TASK
Draft a structured {document_type} from the user-supplied facts below.

USER FACTS
Document type: {document_type}
Parties: {parties}
Terms/conditions: {terms}
Effective date: {effective_date}
Jurisdiction: {jurisdiction}
Additional instructions: {additional_instructions or 'None'}

STRICT RULES
1. Use only facts supplied by the user. Do not invent names, amounts, addresses, dates, obligations, statutes, case law, registration numbers, or signatures.
2. If an important fact is missing, use a clear bracketed placeholder such as [INSERT ADDRESS] instead of inventing it.
3. Produce a professional document with a title, recitals/background where appropriate, numbered sections, definitions where useful, obligations, term/termination, confidentiality where relevant, governing law/jurisdiction where supplied, notices where appropriate, and signature blocks.
4. Reflect the supplied terms faithfully. Do not silently change their meaning.
5. Do not claim that the document is legally valid, legally sound, or reviewed by a lawyer.
6. Do not provide legal advice outside the document. The output should be a draft for human/legal review.
7. Use plain but professional language. Avoid Markdown tables because the export pipeline converts the text to DOCX/PDF.
8. Do not include commentary before or after the draft. Return only the document text.
""".strip()

    def generate_document(self, document_type, parties, terms, effective_date, jurisdiction="Not specified", additional_instructions=""):
        prompt = self.build_prompt(document_type, parties, terms, effective_date, jurisdiction, additional_instructions)
        from google.genai import types
        response = self.client.models.generate_content(
            model=self.model,
            contents=prompt,
            config=types.GenerateContentConfig(
                temperature=0.25,
                max_output_tokens=5000,
            ),
        )
        text = getattr(response, "text", None)
        if not text:
            raise RuntimeError("Gemini returned an empty response.")
        return sanitize_text(text)
