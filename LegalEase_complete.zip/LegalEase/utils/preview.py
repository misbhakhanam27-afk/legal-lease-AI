import html
import re

def format_html_preview(text: str) -> str:
    safe = html.escape(text)
    lines = []
    for line in safe.split("\n"):
        if not line.strip():
            lines.append("<div class='spacer'></div>")
        elif (len(line.strip()) < 90 and line.strip().isupper()) or line.strip().endswith(":"):
            lines.append(f"<h3>{line}</h3>")
        else:
            lines.append(f"<p>{line}</p>")
    return "".join(lines)
