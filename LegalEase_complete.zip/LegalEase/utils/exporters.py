from io import BytesIO
from pathlib import Path
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Inches, Pt
from fpdf import FPDF
from utils.sanitizer import sanitize_text

BASE_DIR = Path(__file__).resolve().parents[1]
LOGO = BASE_DIR / "assets" / "logo.png"


def _add_header(doc: Document, title: str):
    section = doc.sections[0]
    header = section.header
    p = header.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    if LOGO.exists():
        p.add_run().add_picture(str(LOGO), width=Inches(0.7))
    title_p = doc.add_paragraph()
    title_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title_p.add_run(title.upper())
    run.bold = True
    run.font.name = "Times New Roman"
    run.font.size = Pt(15)


def format_docx(text: str, doc_type: str, terms: str = "") -> bytes:
    doc = Document()
    sec = doc.sections[0]
    sec.top_margin = Inches(0.75)
    sec.bottom_margin = Inches(0.75)
    sec.left_margin = Inches(0.9)
    sec.right_margin = Inches(0.9)
    _add_header(doc, doc_type)

    for paragraph_text in sanitize_text(text).split("\n"):
        line = paragraph_text.strip()
        if not line:
            doc.add_paragraph()
            continue
        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(6)
        p.paragraph_format.line_spacing = 1.08
        r = p.add_run(line)
        r.font.name = "Times New Roman"
        r.font.size = Pt(11)
        if (len(line) < 90 and line.isupper()) or line.endswith(":"):
            r.bold = True

    if terms.strip():
        items = [x.strip() for x in terms.split(";") if x.strip()]
        if items:
            doc.add_paragraph()
            heading = doc.add_paragraph()
            rr = heading.add_run("KEY TERMS")
            rr.bold = True
            rr.font.name = "Times New Roman"
            table = doc.add_table(rows=1, cols=2)
            table.style = "Table Grid"
            table.rows[0].cells[0].text = "#"
            table.rows[0].cells[1].text = "Term / Condition"
            for i, item in enumerate(items, 1):
                cells = table.add_row().cells
                cells[0].text = str(i)
                cells[1].text = item

    footer = sec.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    fr = footer.add_run("LegalEase - Draft for review")
    fr.font.name = "Times New Roman"
    fr.font.size = Pt(9)
    output = BytesIO()
    doc.save(output)
    return output.getvalue()


class LegalPDF(FPDF):
    def __init__(self, title):
        super().__init__()
        self.title_text = title
        self.set_auto_page_break(auto=True, margin=18)

    def header(self):
        self.set_font("Helvetica", "B", 10)
        self.cell(0, 7, "LegalEase", align="C")
        self.ln(7)

    def footer(self):
        self.set_y(-14)
        self.set_font("Helvetica", "I", 8)
        self.cell(0, 6, f"LegalEase - Draft for review | Page {self.page_no()}", align="C")


def format_pdf(text: str, doc_type: str, terms: str = "") -> bytes:
    pdf = LegalPDF(doc_type)
    pdf.add_page()
    pdf.set_title(doc_type)
    pdf.set_font("Helvetica", "B", 16)
    pdf.multi_cell(0, 9, doc_type.upper(), align="C")
    pdf.ln(5)
    pdf.set_font("Helvetica", size=10.5)
    for paragraph_text in sanitize_text(text).split("\n"):
        line = paragraph_text.strip()
        if not line:
            pdf.ln(3)
            continue
        is_heading = (len(line) < 90 and line.isupper()) or line.endswith(":")
        pdf.set_font("Helvetica", "B" if is_heading else "", 10.5)
        pdf.multi_cell(0, 5.5, line)
        pdf.ln(1.5)
    if terms.strip():
        pdf.ln(2)
        pdf.set_font("Helvetica", "B", 11)
        pdf.cell(0, 7, "KEY TERMS")
        pdf.ln(7)
        pdf.set_font("Helvetica", size=10)
        for i, item in enumerate([x.strip() for x in terms.split(";") if x.strip()], 1):
            pdf.set_x(pdf.l_margin)
            pdf.multi_cell(pdf.w - pdf.l_margin - pdf.r_margin, 5.5, f"{i}. {item}")
    return bytes(pdf.output())
