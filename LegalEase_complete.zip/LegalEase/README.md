# LegalEase — AI-Powered Legal Document Generator

LegalEase is a full-stack educational/prototype application based on the supplied project specification. It uses Streamlit for the UI, FastAPI for the API, Google's current `google-genai` SDK for Gemini generation, and Python libraries for DOCX/PDF/TXT export.

> **Legal notice:** Generated text is a drafting aid, not legal advice. It can contain omissions or jurisdiction-specific errors. Review documents with a qualified legal professional before signing or relying on them.

## Architecture

```text
Streamlit UI (app.py)
        |
        | POST /generate
        v
FastAPI (main.py + routes.py)
        |
        v
GeminiDocumentGenerator
        |
        v
Google Gemini API

Generated text -> editable preview -> TXT / DOCX / PDF
```

## Project structure

```text
LegalEase/
├── app.py
├── main.py
├── routes.py
├── config.py
├── schemas.py
├── requirements.txt
├── .env.example
├── .gitignore
├── README.md
├── Dockerfile
├── docker-compose.yml
├── Procfile
├── ai_core/
│   ├── __init__.py
│   └── gemini_generator.py
├── utils/
│   ├── __init__.py
│   ├── sanitizer.py
│   ├── exporters.py
│   └── preview.py
├── assets/
│   └── logo.png
└── tests/
    ├── __init__.py
    ├── test_api.py
    └── test_utils.py
```

## VS Code setup (Windows)

1. Install Python 3.10+ and VS Code.
2. Open the `LegalEase` folder in VS Code.
3. Open **Terminal → New Terminal**.
4. Create a virtual environment:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
```

If PowerShell blocks activation, use Command Prompt:

```bat
.venv\Scripts\activate
```

5. Install dependencies:

```powershell
python -m pip install --upgrade pip
pip install -r requirements.txt
```

6. Create `.env` from `.env.example` and put your Gemini API key in `GEMINI_API_KEY`.

7. Start the backend in terminal 1:

```powershell
uvicorn main:app --reload --host 127.0.0.1 --port 8000
```

8. Start Streamlit in terminal 2:

```powershell
streamlit run app.py
```

9. Open the URL printed by Streamlit, normally `http://localhost:8501`.

## API test

Open `http://127.0.0.1:8000/docs` for Swagger UI.

Health check:

```text
GET http://127.0.0.1:8000/health
```

Generate example with PowerShell:

```powershell
$body = @{
  document_type = "Non-Disclosure Agreement"
  parties = "Jane Doe (Disclosing Party); TechNova Inc. (Receiving Party)"
  terms = "Confidential information must be protected; Use confidential information only for evaluation; Termination on 15 days written notice"
  effective_date = "2026-09-24"
  jurisdiction = "India"
  additional_instructions = "Use clear professional language and mark placeholders explicitly."
} | ConvertTo-Json

Invoke-RestMethod -Uri "http://127.0.0.1:8000/generate" -Method Post -ContentType "application/json" -Body $body
```

## Tests

With the virtual environment activated:

```powershell
pytest -q
```

The tests do not call Gemini. The AI client is mocked, so they can run without an API key.

## Docker

Create `.env`, then:

```bash
docker compose up --build
```

The backend is exposed at `http://localhost:8000` and Streamlit at `http://localhost:8501`.

## Troubleshooting

- **401/403 or invalid API key:** check `.env` and restart the backend.
- **Model not found:** set `GEMINI_MODEL` in `.env` to a model currently available to your Gemini API key.
- **CORS errors:** keep the backend and frontend on the documented local ports or update `BACKEND_URL`.
- **PDF font issues:** the exporter uses built-in Helvetica and sanitizes unsupported typography for broad compatibility.
- **DOCX logo missing:** ensure `assets/logo.png` exists.
